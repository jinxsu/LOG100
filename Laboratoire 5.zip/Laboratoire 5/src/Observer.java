public abstract class Observer {

    public abstract void update();

}

